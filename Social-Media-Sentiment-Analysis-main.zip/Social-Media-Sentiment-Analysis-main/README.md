# Social-Media-Sentiment-Analysis
Social Media Sentiment Analysis Using Twitter Dataset (Group project by - Anmol Raj, Paritosh Parihar)<br>
In this we use a data set containing a collection of tweets to detect the sentiment associated with a particular tweet and detect it as negative or positive accordingly using Machine Learning.
